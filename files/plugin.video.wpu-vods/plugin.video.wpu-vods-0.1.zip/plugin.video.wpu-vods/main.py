# TODO translate
# TODO some left info can be reused on episode, in series view
# TODO if trans is used the user/pass code check must be changed
# TODO include publish3r in all credits
# TODO cache get_series, get_vod_streams and add counter in sub cats eg: action (99)

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import os
import time

ADDON = xbmcaddon.Addon()
BASE_URL = ADDON.getSetting("base_url")
USER = ADDON.getSetting("username")
PASS = ADDON.getSetting("password")
API_URL = f"{BASE_URL}/player_api.php?username={USER}&password={PASS}"

try:
    ITEMS_PER_PAGE = int(ADDON.getSetting("items_per_page"))
except:
    ITEMS_PER_PAGE = 50

HANDLE = int(sys.argv[1])
ADDON_DIR = os.path.dirname(__file__)
ADDON_ICON = os.path.join(ADDON_DIR, "icon.png")
ADDON_FANART = os.path.join(ADDON_DIR, "fanart.png")

xbmcplugin.setContent(HANDLE, "videos")


def get_data(action, extra_params=""):
    url = f"{API_URL}&action={action}{extra_params}"
    try:
        r = requests.get(url, timeout=10)
        return r.json()
    except Exception as e:
        print(f"Fehler: {e}")
        return []


def get_fsk_color(fsk_val):
    fsk_str = str(fsk_val)
    if "18" in fsk_str:
        return "red"
    return "orange"


def format_duration(minutes):
    try:
        if not minutes:
            return ""
        total_mins = int(minutes)
        if total_mins <= 0:
            return ""
        hours = total_mins // 60
        mins = total_mins % 60
        return f"{hours}h {mins}m" if hours > 0 else f"{mins}m"
    except:
        return ""


def format_timestamp(ts):
    try:
        if not ts or int(ts) <= 0:
            return "Unbegrenzt"
        return time.strftime("%d.%m.%Y", time.localtime(int(ts)))
    except:
        return "N/A"


def is_released(added_timestamp):
    try:
        if not added_timestamp or added_timestamp == "":
            return True
        return int(added_timestamp) <= int(time.time())
    except:
        return True


def set_stream_properties(li, ext, id, base):
    li.setProperty("IsPlayable", "true")
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.stream_selection_type", "ask-quality")

    ext_str = str(ext).lower()
    if ext_str == "mpd":
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setMimeType("application/dash+xml")
    else:
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        li.setMimeType("application/x-mpegURL")

    #li.setProperty("inputstream.adaptive.license_type", "org.w3.clearkey")
    #li.setProperty("inputstream.adaptive.license_key", f"{base}/lic/{id}|Content-Type=application%2Fjson|R{{SSM}}|")
    li.setProperty("inputstream.adaptive.drm_legacy",f"org.w3.clearkey|{base}/lic/{id}")

def list_main():
    if not USER or USER == "dein_username" or not PASS or PASS == "dein_passwort":
        xbmcgui.Dialog().ok("Konfiguration fehlt", "Bitte gib deine Zugangsdaten in den Einstellungen ein.")
        ADDON.openSettings()
        return
    movies_data = get_data("get_vod_streams")
    series_data = get_data("get_series")
    m_count = len(movies_data) if isinstance(movies_data, list) else 0
    s_count = len(series_data) if isinstance(series_data, list) else 0

    stats_plot = (
        f"[COLOR lightblue][B]XTREAM DASHBOARD[/B][/COLOR]\n"
        f"----------------------------------\n"
        f"[B]Nutzer:[/B] {USER}\n"
        f"[B]Filme gesamt:[/B] [COLOR orange]{m_count}[/COLOR]\n"
        f"[B]Serien gesamt:[/B] [COLOR orange]{s_count}[/COLOR]\n\n"
        f"[I]Hauptmenü[/I]"
    )

    items = [("[COLOR yellow][B]Suche...[/B][/COLOR]", "search"), ("Alle Filme", "list_all_movies"), ("Alle Serien", "list_all_series"), ("Filme", "list_movie_cats"), ("Serien", "list_series_cats")]
    for label, action in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": ADDON_ICON, "poster": ADDON_ICON, "fanart": ADDON_FANART})
        li.setInfo("video", {"plot": stats_plot, "title": label})
        url = f"{sys.argv[0]}?action={action}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_all_movies(current_page):
    data = get_data("get_vod_streams")
    valid_movies = [m for m in data if is_released(m.get("added"))]

    start = current_page * ITEMS_PER_PAGE
    end = start + ITEMS_PER_PAGE
    subset = valid_movies[start:end]

    for m in subset:
        name, fsk, year, dur = m.get("name", ""), m.get("rating", ""), m.get("year", ""), m.get("duration", "")
        v_start = m.get("added")
        v_end = m.get("removed")
        avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

        ext = m.get("container_extension", "mp4")
        duration_sec = int(dur) * 60 if str(dur).isdigit() else 0
        time_display = f" [COLOR lightgreen]({format_duration(dur)})[/COLOR]" if dur else ""

        plot = (
            f"[COLOR lightblue][B]{name}[/B][/COLOR]\n"
            f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]{time_display}\n"
            f"{avail_info}\n"
            f"----------------------------------\n"
            f"[I]Alle Filme[/I]\n\n{m.get('summary', '')}"
        )

        li = xbmcgui.ListItem(label=name)
        icon = m.get("stream_icon", "")
        fanart = m.get("cover_big", icon) if m.get("cover_big") else ADDON_FANART
        li.setArt({"thumb": icon, "poster": icon, "fanart": fanart})
        li.setInfo("video", {"plot": plot, "title": name, "duration": duration_sec})
        set_stream_properties(li, ext, m["stream_id"], BASE_URL)
        v_url = f"{BASE_URL}/kodi_movie/{USER}/{PASS}/{m['stream_id']}.{ext}"
        xbmcplugin.addDirectoryItem(HANDLE, v_url, li, isFolder=False)

    if end < len(valid_movies):
        li = xbmcgui.ListItem(label=f"[COLOR cyan]>>> Nächste Seite ({current_page + 2}) >>>[/COLOR]")
        li.setArt({"thumb": ADDON_ICON, "fanart": ADDON_FANART})
        url = f"{sys.argv[0]}?action=list_all_movies&page={current_page + 1}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_all_series(current_page):
    data = get_data("get_series")
    valid_series = [s for s in data if is_released(s.get("last_modified", s.get("added", "")))]

    start = current_page * ITEMS_PER_PAGE
    end = start + ITEMS_PER_PAGE
    subset = valid_series[start:end]

    for s in subset:
        name, fsk, year = s.get("name", ""), s.get("rating", ""), s.get("year", "")
        v_start = s.get("added")
        v_end = s.get("removed")
        avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

        plot = (
            f"[COLOR lightblue][B]{name}[/B][/COLOR]\n"
            f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]\n"
            f"{avail_info}\n"
            f"----------------------------------\n"
            f"[I]Alle Serien[/I]\n\n{s.get('summary', s.get('plot', ''))}"
        )

        li = xbmcgui.ListItem(label=name)
        cover = s.get("cover", "")
        fanart = s.get("backdrop_path", [ADDON_FANART])[0] if s.get("backdrop_path") else ADDON_FANART
        li.setArt({"thumb": cover, "poster": cover, "fanart": fanart})
        li.setInfo("video", {"plot": plot, "title": name})
        url = f"{sys.argv[0]}?action=get_seasons&series_id={s['series_id']}&cat_name=Alle"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    if end < len(valid_series):
        li = xbmcgui.ListItem(label=f"[COLOR cyan]>>> Nächste Seite ({current_page + 2}) >>>[/COLOR]")
        li.setArt({"thumb": ADDON_ICON, "fanart": ADDON_FANART})
        url = f"{sys.argv[0]}?action=list_all_series&page={current_page + 1}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def search(query=None):
    if not query:
        kb = xbmc.Keyboard("", "Suche Filme & Serien")
        kb.doModal()
        if not kb.isConfirmed():
            return
        query = kb.getText().lower()

    if not query:
        return

    all_movies = get_data("get_vod_streams")
    for m in all_movies:
        if query in m.get("name", "").lower():
            if not is_released(m.get("added")):
                continue
            name, fsk, year, dur = m.get("name", ""), m.get("rating", ""), m.get("year", ""), m.get("duration", "")
            v_start = m.get("added")
            v_end = m.get("removed")
            avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

            ext = m.get("container_extension", "mp4")
            duration_sec = int(dur) * 60 if str(dur).isdigit() else 0
            time_display = f" [COLOR lightgreen]({format_duration(dur)})[/COLOR]" if dur else ""
            custom_plot = (
                f"[COLOR yellow][B]SUCHERGEBNIS (FILM)[/B][/COLOR]\n"
                f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]{time_display}\n"
                f"{avail_info}\n"
                f"----------------------------------\n{m.get('summary', '')}"
            )
            li = xbmcgui.ListItem(label=f"[FILM] {name}")
            icon = m.get("stream_icon", "")
            li.setArt({"thumb": icon, "poster": icon, "fanart": m.get("cover_big", ADDON_FANART)})
            li.setInfo("video", {"plot": custom_plot, "title": name, "duration": duration_sec})
            set_stream_properties(li, ext, m["stream_id"], BASE_URL)
            v_url = f"{BASE_URL}/kodi_movie/{USER}/{PASS}/{m['stream_id']}.{ext}"
            xbmcplugin.addDirectoryItem(HANDLE, v_url, li, isFolder=False)

    all_series = get_data("get_series")
    for s in all_series:
        if query in s.get("name", "").lower():
            added_val = s.get("last_modified", s.get("added", ""))
            if not is_released(added_val):
                continue
            name, fsk, year = s.get("name", ""), s.get("rating", ""), s.get("year", "")
            v_start = s.get("added")
            v_end = s.get("removed")
            avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

            custom_plot = (
                f"[COLOR yellow][B]SUCHERGEBNIS (SERIE)[/B][/COLOR]\n"
                f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]\n"
                f"{avail_info}\n"
                f"----------------------------------\n{s.get('summary', s.get('plot', ''))}"
            )
            li = xbmcgui.ListItem(label=f"[SERIE] {name}")
            cover = s.get("cover", "")
            li.setArt({"thumb": cover, "poster": cover, "fanart": s.get("backdrop_path", [ADDON_FANART])[0]})
            li.setInfo("video", {"plot": custom_plot, "title": name})
            url = f"{sys.argv[0]}?action=get_seasons&series_id={s['series_id']}&cat_name=Suche&search_query={urllib.parse.quote(query)}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_movie_categories():
    cats = get_data("get_vod_categories")
    for cat in cats:
        cat_name = cat["category_name"]
        nav_plot = (
            f"[COLOR lightblue][B]FILM-KATEGORIEN[/B][/COLOR]\n"
            f"----------------------------------\n"
            f"[B]Bereich:[/B] Filme\n"
            f"[B]Kategorie:[/B] [COLOR orange]{cat_name}[/COLOR]\n\n"
            f"Öffne diese Kategorie, um alle Filme anzuzeigen."
        )
        li = xbmcgui.ListItem(label=cat_name)
        li.setArt({"thumb": ADDON_ICON, "poster": ADDON_ICON, "fanart": ADDON_FANART})
        li.setInfo("video", {"plot": nav_plot, "title": cat_name})
        url = f"{sys.argv[0]}?action=list_movies&cat_id={cat['category_id']}&cat_name={urllib.parse.quote(cat_name)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_movies_in_cat(cat_id, cat_name):
    movies = get_data("get_vod_streams", f"&category_id={cat_id}")
    for m in movies:
        if not is_released(m.get("added")):
            continue
        name, fsk, year, dur = m.get("name", ""), m.get("rating", ""), m.get("year", ""), m.get("duration", "")
        v_start = m.get("added")
        v_end = m.get("removed")
        avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

        ext = m.get("container_extension", "mp4")
        duration_sec = int(dur) * 60 if str(dur).isdigit() else 0
        time_display = f" [COLOR lightgreen]({format_duration(dur)})[/COLOR]" if dur else ""
        custom_plot = (
            f"[COLOR lightblue][B]{name}[/B][/COLOR]\n"
            f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]{time_display}\n"
            f"{avail_info}\n"
            f"----------------------------------\n"
            f"[I]Filme > {cat_name}[/I]\n\n{m.get('summary', '')}"
        )
        li = xbmcgui.ListItem(label=name)
        icon = m.get("stream_icon", "")
        li.setArt({"thumb": icon, "poster": icon, "fanart": m.get("cover_big", ADDON_FANART)})
        li.setInfo("video", {"plot": custom_plot, "title": name, "duration": duration_sec})
        set_stream_properties(li, ext, m["stream_id"], BASE_URL)
        v_url = f"{BASE_URL}/kodi_movie/{USER}/{PASS}/{m['stream_id']}.{ext}"
        xbmcplugin.addDirectoryItem(HANDLE, v_url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def list_series_categories():
    cats = get_data("get_series_categories")
    for cat in cats:
        cat_name = cat["category_name"]
        nav_plot = (
            f"[COLOR lightblue][B]SERIEN-KATEGORIEN[/B][/COLOR]\n"
            f"----------------------------------\n"
            f"[B]Bereich:[/B] Serien\n"
            f"[B]Kategorie:[/B] [COLOR orange]{cat_name}[/COLOR]\n\n"
            f"Öffne diese Kategorie für alle Staffeln."
        )
        li = xbmcgui.ListItem(label=cat_name)
        li.setArt({"thumb": ADDON_ICON, "poster": ADDON_ICON, "fanart": ADDON_FANART})
        li.setInfo("video", {"plot": nav_plot, "title": cat_name})
        url = f"{sys.argv[0]}?action=list_series&cat_id={cat['category_id']}&cat_name={urllib.parse.quote(cat_name)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_series_in_cat(cat_id, cat_name):
    series = get_data("get_series", f"&category_id={cat_id}")
    for s in series:
        added_val = s.get("last_modified", s.get("added", ""))
        if not is_released(added_val):
            continue
        name, fsk, year = s.get("name", ""), s.get("rating", ""), s.get("year", "")
        v_start = s.get("added")
        v_end = s.get("removed")
        avail_info = f"[COLOR gray]Verfügbar:[/COLOR] {format_timestamp(v_start)} - {format_timestamp(v_end)}"

        custom_plot = (
            f"[COLOR lightblue][B]{name}[/B][/COLOR]\n"
            f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR] [COLOR gray]({year})[/COLOR]\n"
            f"{avail_info}\n"
            f"----------------------------------\n"
            f"[I]Serien > {cat_name}[/I]\n\n{s.get('summary', s.get('plot', ''))}"
        )
        li = xbmcgui.ListItem(label=name)
        cover = s.get("cover", "")
        li.setArt({"thumb": cover, "poster": cover, "fanart": s.get("backdrop_path", [ADDON_FANART])[0]})
        li.setInfo("video", {"plot": custom_plot, "title": name})
        url = f"{sys.argv[0]}?action=get_seasons&series_id={s['series_id']}&cat_name={urllib.parse.quote(cat_name)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_seasons(series_id, cat_name, search_query=None):
    data = get_data("get_series_info", f"&series_id={series_id}")
    s_info, seasons = data.get("info", {}), data.get("seasons", [])
    series_name, fsk, cover = s_info.get("name", ""), s_info.get("rating", ""), s_info.get("cover", "")
    for s in seasons:
        s_num = s.get("season_number")
        custom_plot = (
            f"[COLOR lightblue][B]{series_name}[/B][/COLOR]\n"
            f"[COLOR {get_fsk_color(fsk)}]FSK: {fsk}[/COLOR]\n"
            f"----------------------------------\n"
            f"[I]Serien > {cat_name} > Staffel {s_num}[/I]\n\n"
            f"{s_info.get('summary', s_info.get('plot', ''))}"
        )
        li = xbmcgui.ListItem(label=f"Staffel {s_num}")
        li.setArt({"thumb": cover, "poster": cover, "fanart": s_info.get("backdrop_path", [ADDON_FANART])[0]})
        li.setInfo("video", {"plot": custom_plot, "title": series_name})

        url = f"{sys.argv[0]}?action=list_episodes&series_id={series_id}&season={s_num}&cat_name={urllib.parse.quote(cat_name)}"
        if search_query:
            url += f"&search_query={urllib.parse.quote(search_query)}"

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_episodes(series_id, season_num, cat_name):
    data = get_data("get_series_info", f"&series_id={series_id}")
    s_info = data.get("info", {})
    series_name = s_info.get("name", "")
    episodes = data.get("episodes", {}).get(str(season_num), [])
    for ep in episodes:
        if not is_released(ep.get("added")):
            continue
        title, s_e = ep.get("title", "Episode"), f"S{str(season_num).zfill(2)}E{str(ep.get('episode_num', 0)).zfill(2)}"
        ep_info = ep.get("info", {})
        dur, ext = ep_info.get("duration", ""), ep.get("container_extension", "mp4")
        duration_sec = int(dur) * 60 if str(dur).isdigit() else 0
        time_display = f" [COLOR lightgreen]({format_duration(dur)})[/COLOR]" if dur else ""
        custom_plot = (
            f"[COLOR lightblue][B]{series_name}[/B][/COLOR]\n"
            f"[I]{s_e} - {title}[/I]\n"
            f"[COLOR orange]FSK: {ep_info.get('rating', '')}[/COLOR]{time_display}\n"
            f"----------------------------------\n"
            f"[I]Genre: {cat_name}[/I]\n\n{ep_info.get('summary', ep_info.get('plot',''))}"
        )
        li = xbmcgui.ListItem(label=f"{s_e} - {title}")
        ep_img = ep_info.get("movie_image", s_info.get("cover", ADDON_FANART))
        li.setArt({"thumb": ep_img, "poster": ep_img, "fanart": ep_img})
        li.setInfo("video", {"plot": custom_plot, "title": title, "duration": duration_sec})
        set_stream_properties(li, ext, ep["id"], BASE_URL)
        v_url = f"{BASE_URL}/kodi_series/{USER}/{PASS}/{ep['id']}.{ext}"
        xbmcplugin.addDirectoryItem(HANDLE, v_url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action")
page = int(params.get("page", 0))
search_query = params.get("search_query")

if not action:
    list_main()
elif action == "search":
    search(search_query)
elif action == "list_all_movies":
    list_all_movies(page)
elif action == "list_all_series":
    list_all_series(page)
elif action == "list_movie_cats":
    list_movie_categories()
elif action == "list_movies":
    list_movies_in_cat(params.get("cat_id"), params.get("cat_name"))
elif action == "list_series_cats":
    list_series_categories()
elif action == "list_series":
    list_series_in_cat(params.get("cat_id"), params.get("cat_name"))
elif action == "get_seasons":
    list_seasons(params.get("series_id"), params.get("cat_name"), search_query)
elif action == "list_episodes":
    list_episodes(params.get("series_id"), params.get("season"), params.get("cat_name"))
