#scp -P 2222 -r root@10.21.1.93:/storage/emulated/0/kodi_21/.kodi/temp/kodi.log kodi.tmp
#scp -P 2222 -r root@10.21.1.9:/storage/emulated/0/kodi_21/.kodi/temp/kodi.log kodi.tmp
scp -P 2222 -r root@10.21.1.17:/storage/emulated/0/kodi_21/.kodi/temp/kodi.log kodi.tmp

#cat kodi.tmp|grep -v 'info <general>' > kodi.log
#rm -f kodi.tmp

mv kodi.tmp kodi.log