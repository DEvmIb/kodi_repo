﻿import sys
import urllib.request, urllib.parse, urllib.error
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import requests
import json
import os
import time

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
addon = xbmcaddon.Addon()

mode = args.get("mode", None)

addon_icon = "special://home/addons/plugin.telerising/icon.png"
addon_fanart = "special://home/addons/plugin.video.telerising/fanart.jpg"
settings_icon = "special://home/addons/plugin.video.telerising/resources/settings.png"
info_icon = "special://home/addons/plugin.video.telerising/resources/info.png"
tv_icon = "special://home/addons/plugin.video.telerising/resources/tv.png"
fav_icon = "special://home/addons/plugin.video.telerising/resources/favorites.png"
rec_icon = "special://home/addons/plugin.video.telerising/resources/recordings.png"

update = addon.getSetting("update")
password = addon.getSetting("password")
TELERISING_URL = addon.getSetting("url")
LICENSE_PROXY = f"{TELERISING_URL}/api/license_proxy/{{}}/{{}}"
LICENSE_SERVER = f"{TELERISING_URL}/api/license/{{}}/{{}}"
LICENSE_CONFIG = f"{TELERISING_URL}/api/license_config/{{}}/{{}}"
LIVE_URL = f"{TELERISING_URL}/api/all/channels.json"
FAV_URL = f"{TELERISING_URL}/api/provider/file/favorites.m3u"
REC_URL = f"{TELERISING_URL}/api/provider/file/recordings.m3u"
MANIFEST_URL = f"{TELERISING_URL}/api/{{}}/live/{{}}.{{}}?l1=1"

EASYEPG_URL = addon.getSetting("easyepg_url")

CHANNEL_CACHE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")) + "channels_cache.json"
CACHE_TIME = 3600

LIC_CACHE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")) + "lic_cache.json"


def get_lic_cache(provider_id, channel_id):
    if os.path.isfile(LIC_CACHE):
        with open(LIC_CACHE, "r") as f:
            lic_cache = json.load(f)
            if lic_cache.get(provider_id) and lic_cache[provider_id].get(channel_id):
                if lic_cache[provider_id][channel_id]["cache_time"] > time.time():
                    return lic_cache[provider_id][channel_id]
    return {}


def update_lic_cache(provider_id, channel_id, lic_url, lic_headers, cache_time):
    lic_cache = {}
    if os.path.isfile(LIC_CACHE):
        with open(LIC_CACHE, "r") as f:
            lic_cache = json.load(f)
    if not lic_cache.get(provider_id):
        lic_cache[provider_id] = {}
    lic_cache[provider_id][channel_id] = {"lic_url": lic_url, "lic_headers": lic_headers, "cache_time": cache_time}

    for p_id in list(lic_cache.keys()):
        for c_id in list(lic_cache[p_id].keys()):
            if lic_cache[p_id][c_id]["cache_time"] < time.time():
                del lic_cache[p_id][c_id]
        if not lic_cache[p_id]:
            del lic_cache[p_id]

    with open(LIC_CACHE, "w") as f:
        json.dump(lic_cache, f)


def get_channel_cache():
    cache = {}
    if os.path.isfile(CHANNEL_CACHE) and int(addon.getSetting("cache_time") or 0) > time.time():
        with open(CHANNEL_CACHE, "r") as f:
            cache = json.load(f)
    else:
        os.makedirs(os.path.dirname(CHANNEL_CACHE), exist_ok=True)
        try:
            cache = requests.get(LIVE_URL, timeout=120).json()
        except:
            popup("channel list update failed", "error communicate with telerising")
            return cache
        with open(CHANNEL_CACHE, "w") as f:
            json.dump(cache, f)
        addon.setSetting("cache_time", str(int(time.time() + CACHE_TIME)))
    return cache


def build_url(query):
    return base_url + "?" + urllib.parse.urlencode(query)


def menu():

    cache = get_channel_cache()
    for provider_id in cache.keys():
        provider_name = cache[provider_id]["name"]
        url = build_url({"mode": "provider", "provider_id": provider_id})
        li = xbmcgui.ListItem(f"{provider_name}")
        li.setInfo("Video", {"title": f"{provider_name}", "plot": f"{provider_name}"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({"mode": "settings"})
    li = xbmcgui.ListItem("Settings")
    li.setInfo("Video", {"title": "Settings", "plot": "Settings"})
    li.setProperty("IsPlayable", "false")
    li.setArt({"fanart": addon_fanart, "icon": settings_icon, "thumb": settings_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    url = build_url({"mode": "clear_channel_cache"})
    li = xbmcgui.ListItem("Clear Channel Cache")
    li.setInfo("Video", {"title": "Clear Channel Cache", "plot": "Clear Channel Cache"})
    li.setProperty("IsPlayable", "false")
    li.setArt({"fanart": addon_fanart, "icon": settings_icon, "thumb": settings_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def submenu(provider, code):
    url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "livetv"})
    li = xbmcgui.ListItem("Live TV")
    li.setInfo("Video", {"title": "Live TV", "plot": "Live TV"})
    li.setArt({"fanart": addon_fanart, "icon": tv_icon, "thumb": tv_icon})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "favorites"})
    # li = xbmcgui.ListItem("Favorites")
    # li.setInfo("Video", {"title": "Favorites", "plot": "Favorites"})
    # li.setArt({"fanart": addon_fanart, "icon": fav_icon, "thumb": fav_icon})
    # li.setProperty("IsPlayable", "false")
    # xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "recordings"})
    # li = xbmcgui.ListItem("Recordings")
    # li.setInfo("Video", {"title": "Recordings", "plot": "Recordings"})
    # li.setArt({"fanart": addon_fanart, "icon": rec_icon, "thumb": rec_icon})
    # li.setProperty("IsPlayable", "false")
    # xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def parse_epg_field(val, default):
    if isinstance(val, (dict, list)):
        return val
    if isinstance(val, str):
        try:
            return json.loads(val)
        except (json.JSONDecodeError, ValueError):
            pass
    return default


def truncate_text(text, max_len=20):
    return text if len(text) <= max_len else text[:max_len] + ".."


def playlist(provider_id):

    def parse_epg_field(val, default):
        if isinstance(val, (dict, list)):
            return val
        if isinstance(val, str):
            try:
                return json.loads(val)
            except (json.JSONDecodeError, ValueError):
                pass
        return default

    def truncate_text(text, max_len=30):
        return text if len(text) <= max_len else text[:max_len] + ".."

    cache = get_channel_cache()
    channels = cache.get(provider_id, {}).get("channels", {})
    epg = {}
    if EASYEPG_URL and addon.getSetting("enable_easyepg") == "true":
        xbmc.log("easyepg on", xbmc.LOGINFO)
        epg_q = {"channels": [], "start_time": int(time.time()), "count": 2}
        for channel_id in channels:
            name = cache[provider_id]["channels"][channel_id]["name"].lower()
            if name not in epg_q["channels"]:
                epg_q["channels"].append(name)
        try:
            epg = requests.post(f"{EASYEPG_URL}/api/search-broadcast", json=epg_q, headers={"Content-Type": "application/json"}, timeout=10).json()
        except Exception as e:
            popup("easyepg failed", "easyepg not reachable")
            xbmc.log(f"easyepg error: {e}", xbmc.LOGINFO)

    for channel_id in sorted(channels.keys(), key=lambda cid: channels[cid]["name"].lower()):
        channel_name = cache[provider_id]["channels"][channel_id]["name"]
        channel_icon = cache[provider_id]["channels"][channel_id]["logo_url"]
        channel_manifest_type = cache[provider_id]["channels"][channel_id]["manifest_type"]

        current = epg.get("result", {}).get(channel_name.lower(), {}).get("current")

        if current:
            image = current.get("image", "")
            title = truncate_text(current.get("title", ""))
            subtitle = current.get("subtitle", "")
            desc = current.get("desc", "")
            start = current.get("start", 0)
            end = current.get("end", 0)
            genres = parse_epg_field(current.get("genres"), [])
            rating = parse_epg_field(current.get("rating"), {})
            credits = parse_epg_field(current.get("credits"), {})
            season_episode = parse_epg_field(current.get("season_episode_num"), {})

            start_str = time.strftime("%H:%M", time.localtime(start)) if start else ""
            end_str = time.strftime("%H:%M", time.localtime(end)) if end else ""
            time_range = f"{start_str}–{end_str}" if start_str else ""

            display_name = f"[B]{channel_name}[/B]  •  [COLOR yellow]{start_str}[/COLOR]  {title}" if title else f"[B]{channel_name}[/B]"

            plot_parts = []

            if time_range:
                plot_parts.append(f"[B]{time_range}[/B]  {title}")
            if subtitle:
                plot_parts.append(subtitle)

            next_list = epg.get("result", {}).get(channel_name.lower(), {}).get("next", [])
            next_event = next_list[0] if next_list else None
            if next_event:
                next_title = truncate_text(next_event.get("title", ""))
                next_start = next_event.get("start", 0)
                next_start_str = time.strftime("%H:%M", time.localtime(next_start)) if next_start else ""
                if next_title:
                    plot_parts.append(f"[COLOR gray]{next_start_str}  {next_title}[/COLOR]")

            plot_parts.append("")

            if desc:
                plot_parts.append(desc)
            if genres:
                plot_parts.append("Genre: " + ", ".join(genres))

            if isinstance(season_episode, dict):
                ep_info = []
                season = season_episode.get("season")
                episode = season_episode.get("episode")
                if season is not None:
                    ep_info.append(f"S{int(season):02d}")
                if episode is not None:
                    ep_info.append(f"E{int(episode):02d}")
                if ep_info:
                    plot_parts.append(" ".join(ep_info))

            if isinstance(credits, dict):
                if credits.get("director"):
                    plot_parts.append("Director: " + ", ".join(credits["director"]))
                if credits.get("actor"):
                    actors = [a.get("name", a) if isinstance(a, dict) else a for a in credits["actor"][:4]]
                    plot_parts.append("Actor's: " + ", ".join(actors))

            plot = "\n".join(plot_parts)

            mpaa = ""
            if isinstance(rating, dict) and rating:
                mpaa = next(iter(rating.values()), "")
            elif isinstance(rating, str):
                mpaa = rating

        else:
            display_name = channel_name
            plot = channel_name
            mpaa = ""
            image = ""

        url = build_url(
            {
                "mode": "play_channel",
                "provider_id": provider_id,
                "channel_id": channel_id,
                "channel_name": channel_name,
                "channel_icon": channel_icon,
                "channel_manifest_type": channel_manifest_type,
            }
        )
        li = xbmcgui.ListItem(display_name)
        li.setInfo(
            "Video",
            {
                "title": display_name,
                "plot": plot,
                "mpaa": mpaa,
            },
        )
        li.setArt(
            {
                "fanart": image or addon_fanart,
                "icon": channel_icon,
                "thumb": image or channel_icon,
            }
        )
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)

    """if listtype == "livetv":
        playlist = LIVE_URL.replace("/provider/", f"/{provider}/")
        rep = playlist.replace("/file/channels.json", "/live/placeholder")
    if listtype == "favorites":
        playlist = FAV_URL.replace("/provider/", f"/{provider}/")
        rep = playlist.replace("/file/favorites.m3u", "/live/placeholder")
    if listtype == "recordings":
        playlist = REC_URL.replace("/provider/", f"/{provider}/")
        rep = ""

    if manifest == "true":
        playlist = playlist + "?platform=dash"
        rep = rep + "?platform=dash"
    if manifest == "false":
        playlist = playlist + "?platform=hls7"
        rep = rep + "?platform=hls7"

    if not code == "false":
        playlist = playlist + f"&code={code}"
        rep = rep + f"&code={code}"

    r = requests.get(playlist, timeout=5)
    if listtype == "recordings":
        sid = re.compile("/pvr/(.+?)\n").findall(r.content.decode("utf-8"))
    else:
        sid = re.compile("/live/(.+?)\n").findall(r.content.decode("utf-8"))
    match = re.compile('tvg-logo="(.+?)", (.+?)\n').findall(r.content.decode("utf-8"))
    if "inputstream.adaptive.drm_legacy" in r.content.decode("utf-8"):
        drm = str(re.compile("clearkey(.+?)\n").findall(r.content.decode("utf-8"))[0])
        drm = drm.replace("|", "")
    else:
        drm = "false"
    i = 0
    for image, name in match:
        station = sid[i]
        if manifest == "true":
            station = station.split(".mpd")[0]
            station = station.replace(".mpd", "")
        else:
            station = station.split(".m3u8")[0]
            station = station.replace(".m3u8", "")
        station = station.split("?")[0]
        station = station.replace("?", "")
        if manifest == "true":
            if listtype == "recordings":
                stream = TELERISING_URL + "/api/" + provider + "/pvr/" + station + ".mpd" + rep
            else:
                stream = rep.replace("placeholder", f"{station}.mpd")
        else:
            if listtype == "recordings":
                stream = TELERISING_URL + "/api/" + provider + "/pvr/" + station + ".m3u8" + rep
            else:
                stream = rep.replace("placeholder", f"{station}.m3u8")
        url = build_url({"mode": "play", "stream": stream, "name": name, "logo": image, "drm": drm})
        li = xbmcgui.ListItem(name)
        li.setInfo("Video", {"title": name, "plot": name})
        li.setArt({"fanart": addon_fanart, "icon": image, "thumb": image})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        i = i + 1
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)"""


def play(provider_id, channel_id, channel_icon, channel_manifest_type):
    v = xbmc.getInfoLabel("System.BuildVersion")
    major = int(re.search(r"(\d+)", v).group(1))
    lic_config = {}
    try:
        lic_config = requests.get(LICENSE_CONFIG.format(provider_id, channel_id)).json()
    except:
        popup("lic config failed", "failed to retrieve lic config from telerising")
        return

    if channel_manifest_type == "hls":
        ext = "m3u8"
    else:
        ext = "mpd"

    if xbmc.Player().isPlaying():
        xbmc.Player().stop()

    play_item = xbmcgui.ListItem(path=channel_id)
    play_item.setContentLookup(False)
    play_item.setProperty("IsPlayable", "true")
    play_item.setInfo("Video", {"title": channel_id, "plot": channel_id})
    play_item.setArt({"fanart": addon_fanart, "thumb": channel_icon, "icon": channel_icon})
    play_item.setProperty("inputstream", "inputstream.adaptive")

    if channel_manifest_type == "dash":
        play_item.setMimeType("application/dash+xml")
        play_item.setProperty("inputstream.adaptive.manifest_type", "mpd")

    if channel_manifest_type[:3] == "hls":
        play_item.setMimeType("application/vnd.apple.mpegurl")

    if major >= 21:
        play_item.setProperty(
            "inputstream.adaptive.drm_legacy",
            f"{lic_config.get('type','com.widevine.alpha')}|{LICENSE_PROXY.format(provider_id,channel_id) if lic_config.get('type','com.widevine.alpha')=='com.widevine.alpha' else LICENSE_SERVER.format(provider_id,channel_id)}|",
        )
    else:
        play_item.setProperty("inputstream.adaptive.license_type", lic_config.get("challenge", "com.widevine.alpha"))
        play_item.setProperty(
            "inputstream.adaptive.license_key",
            f"{LICENSE_PROXY.format(provider_id,channel_id) if lic_config.get('type','com.widevine.alpha')=='com.widevine.alpha' else LICENSE_SERVER.format(provider_id,channel_id)}|{lic_config.get('content-type','Content-Type=application%2Foctet-stream')}|{lic_config.get('challenge','R')}{{{lic_config.get('signed','SSM')}}}|",
        )

    xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
    xbmc.Player().play(item=MANIFEST_URL.format(provider_id, channel_id, ext), listitem=play_item)


def popup(title, msg):
    dialog = xbmcgui.Dialog()
    dialog.ok(title, msg)


if mode is None:
    menu()

elif mode[0] == "folder":
    provider = args["provider"][0]
    code = args["code"][0]
    submenu(provider, code)

elif mode[0] == "playlist":
    provider = args["provider"][0]
    code = args["code"][0]
    listtype = args["list"][0]
    playlist(provider, code, listtype)

elif mode[0] == "play_channel":
    provider_id = args["provider_id"][0]
    channel_id = args["channel_id"][0]
    channel_icon = args["channel_icon"][0]
    channel_manifest_type = args["channel_manifest_type"][0]
    play(provider_id, channel_id, channel_icon, channel_manifest_type)

elif mode[0] == "info":
    text = ""
    dialog = xbmcgui.Dialog()
    dialog.textviewer("Telerising", text)

elif mode[0] == "settings":
    addon.openSettings()
    xbmc.executebuiltin("Container.Refresh")

elif mode[0] == "clear_channel_cache":
    if os.path.isfile(CHANNEL_CACHE):
        if os.path.isfile(LIC_CACHE):
            os.unlink(LIC_CACHE)
        os.unlink(CHANNEL_CACHE)
        addon.setSetting("cache_time", "0")
        popup("Channel Cache", "cleared")
    else:
        popup("Channel Cache", "not needed")

elif mode[0] == "provider":
    provider = args["provider_id"][0]
    playlist(provider)
