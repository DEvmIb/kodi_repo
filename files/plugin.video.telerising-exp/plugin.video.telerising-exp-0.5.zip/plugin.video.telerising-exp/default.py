﻿import sys
import urllib.request, urllib.parse, urllib.error
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
import requests
import json

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
addon = xbmcaddon.Addon()

mode = args.get("mode", None)

addon_icon = "special://home/addons/plugin.telerising/icon.png"
addon_fanart = "special://home/addons/plugin.video.telerising/fanart.jpg"
settings_icon = "special://home/addons/plugin.video.telerising/resources/settings.png"
info_icon = "special://home/addons/plugin.video.telerising/resources/info.png"
tv_icon = "special://home/addons/plugin.video.telerising/resources/tv.png"
fav_icon = "special://home/addons/plugin.video.telerising/resources/favorites.png"
rec_icon = "special://home/addons/plugin.video.telerising/resources/recordings.png"

update = addon.getSetting("update")
password = addon.getSetting("password")
telerising_url = addon.getSetting("url")
login_url = f"{telerising_url}/api/login_check"
live_url = f"{telerising_url}/api/provider/file/channels.m3u"
fav_url = f"{telerising_url}/api/provider/file/favorites.m3u"
rec_url = f"{telerising_url}/api/provider/file/recordings.m3u"


def build_url(query):
    return base_url + "?" + urllib.parse.urlencode(query)


def menu():
    try:
        r = requests.get("https://github.com/DEvmIb/telerising-builds/releases/latest", timeout=5)
        available = re.findall('https://github.com/DEvmIb/telerising-builds/releases/tag/(.*?)"', r.text, re.DOTALL | re.MULTILINE)[0]
        available = re.search(r"-(.*?)-", available)
        available = available.group(1)
    except:
        available = "?"

    response = requests.post(login_url, data={"pw": password}, timeout=5)
    response.raise_for_status()

    session_cookies = response.cookies.get_dict()
    session_id = session_cookies.get("sessionID", None)
    session = session_cookies.get("session", None)

    cookies = {"session": session, "sessionID": session_id}
    status_response = requests.get(telerising_url, cookies=cookies, timeout=5)
    status_response.raise_for_status()

    get_status = re.findall("var test = (.*?)</script>", status_response.text, re.DOTALL | re.MULTILINE)[0]
    get_status = get_status.strip()
    json_data = json.loads(get_status)

    current = "v"  # + re.findall('<span class="text-muted">API v(.*?) - ',status_response.text,re.DOTALL|re.MULTILINE)[0]

    content = re.findall("!-- Status Cards -->(.*?)<!-- Settings -->", status_response.text, re.DOTALL | re.MULTILINE)[0]
    match = re.findall('-header" style="margin-bottom: 0px;">(.*?)</p>', content, re.DOTALL | re.MULTILINE)
    i = 0
    for title in match:
        title = title.strip()
        provider = re.findall("/player/(.*?)/channels.html", content, re.DOTALL | re.MULTILINE)[i]
        code = re.findall('-code-input" type="text" class="form-control" placeholder="(.*?)>', content, re.DOTALL | re.MULTILINE)[i]
        try:
            status = json_data[f"{provider}"]["status"]
        except:
            status = f"[COLOR yellow]?[/COLOR]"
        if status == "OK":
            status = f"[COLOR green]{status}[/COLOR]"
        if status == "ERROR":
            status = f"[COLOR red]{status}[/COLOR]"
        title = title + f" [{status}]"
        i = i + 1
        try:
            code = re.findall('value="(.*?)"', code, re.DOTALL | re.MULTILINE)[0]
        except:
            code = "false"
        url = build_url({"mode": "folder", "provider": provider, "code": code})
        li = xbmcgui.ListItem(f"{title}")
        li.setInfo("Video", {"title": f"{title}", "plot": f"{title}"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    if update == "true":
        try:
            a = current[1:]
            a = a.replace(".", "")
            a = int(a)
            b = available[1:]
            b = b.replace(".", "")
            b = int(b)
            if a < b:
                xbmc.executebuiltin("Notification(%s, %s, %d, %s)" % ("[B]Telerising API[/B]", f"{available} is available.", 5000, addon_icon))
        except:
            pass

    info = f"Installed: {current} | Latest: {available}"
    url = build_url({"mode": "info"})
    li = xbmcgui.ListItem(info)
    li.setInfo("Video", {"title": info, "plot": info})
    li.setProperty("IsPlayable", "false")
    li.setArt({"fanart": addon_fanart, "icon": info_icon, "thumb": info_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    url = build_url({"mode": "settings"})
    li = xbmcgui.ListItem("Settings")
    li.setInfo("Video", {"title": "Settings", "plot": "Settings"})
    li.setProperty("IsPlayable", "false")
    li.setArt({"fanart": addon_fanart, "icon": settings_icon, "thumb": settings_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


def submenu(provider, code):
    url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "livetv"})
    li = xbmcgui.ListItem("Live TV")
    li.setInfo("Video", {"title": "Live TV", "plot": "Live TV"})
    li.setArt({"fanart": addon_fanart, "icon": tv_icon, "thumb": tv_icon})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "favorites"})
    li = xbmcgui.ListItem("Favorites")
    li.setInfo("Video", {"title": "Favorites", "plot": "Favorites"})
    li.setArt({"fanart": addon_fanart, "icon": fav_icon, "thumb": fav_icon})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({"mode": "playlist", "provider": provider, "code": code, "list": "recordings"})
    li = xbmcgui.ListItem("Recordings")
    li.setInfo("Video", {"title": "Recordings", "plot": "Recordings"})
    li.setArt({"fanart": addon_fanart, "icon": rec_icon, "thumb": rec_icon})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def manifest(provider):
    if provider == "ntv":
        manifest = "false"
    elif provider == "tvp":
        manifest = "false"
    elif provider == "n3o":
        manifest = "false"
    else:
        manifest = addon.getSetting("manifest")
    return manifest


def playlist(provider, code, listtype, manifest):
    if listtype == "livetv":
        playlist = live_url.replace("/provider/", f"/{provider}/")
        rep = playlist.replace("/file/channels.m3u", "/live/placeholder")
    if listtype == "favorites":
        playlist = fav_url.replace("/provider/", f"/{provider}/")
        rep = playlist.replace("/file/favorites.m3u", "/live/placeholder")
    if listtype == "recordings":
        playlist = rec_url.replace("/provider/", f"/{provider}/")
        rep = ""

    if manifest == "true":
        playlist = playlist + "?platform=dash"
        rep = rep + "?platform=dash"
    if manifest == "false":
        playlist = playlist + "?platform=hls7"
        rep = rep + "?platform=hls7"

    if not code == "false":
        playlist = playlist + f"&code={code}"
        rep = rep + f"&code={code}"

    r = requests.get(playlist, timeout=5)
    if listtype == "recordings":
        sid = re.compile("/pvr/(.+?)\n").findall(r.content.decode("utf-8"))
    else:
        sid = re.compile("/live/(.+?)\n").findall(r.content.decode("utf-8"))
    match = re.compile('tvg-logo="(.+?)", (.+?)\n').findall(r.content.decode("utf-8"))
    if "inputstream.adaptive.drm_legacy" in r.content.decode("utf-8"):
        drm = str(re.compile("clearkey(.+?)\n").findall(r.content.decode("utf-8"))[0])
        drm = drm.replace("|", "")
    else:
        drm = "false"
    i = 0
    for image, name in match:
        station = sid[i]
        if manifest == "true":
            station = station.split(".mpd")[0]
            station = station.replace(".mpd", "")
        else:
            station = station.split(".m3u8")[0]
            station = station.replace(".m3u8", "")
        station = station.split("?")[0]
        station = station.replace("?", "")
        if manifest == "true":
            if listtype == "recordings":
                stream = telerising_url + "/api/" + provider + "/pvr/" + station + ".mpd" + rep
            else:
                stream = rep.replace("placeholder", f"{station}.mpd")
        else:
            if listtype == "recordings":
                stream = telerising_url + "/api/" + provider + "/pvr/" + station + ".m3u8" + rep
            else:
                stream = rep.replace("placeholder", f"{station}.m3u8")
        url = build_url({"mode": "play", "stream": stream, "name": name, "logo": image, "drm": drm})
        li = xbmcgui.ListItem(name)
        li.setInfo("Video", {"title": name, "plot": name})
        li.setArt({"fanart": addon_fanart, "icon": image, "thumb": image})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        i = i + 1
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)


def play_old(stream, name, logo, drm):
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()
    play_item = xbmcgui.ListItem(path=stream)
    play_item.setContentLookup(False)
    play_item.setProperty("IsPlayable", "true")
    play_item.setInfo("Video", {"title": name, "plot": name})
    play_item.setArt({"fanart": addon_fanart, "thumb": logo, "icon": logo})
    play_item.setProperty("inputstream", "inputstream.adaptive")
    if ".mpd" in stream:
        play_item.setMimeType("application/dash+xml")
        if not drm == "false":
            play_item.setProperty("inputstream.adaptive.drm_legacy", f"org.w3.clearkey|{drm}")
    if ".m3u8" in stream:
        play_item.setMimeType("application/vnd.apple.mpegurl")
    xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
    xbmc.Player().play(item=stream, listitem=play_item)


def play(stream, name, logo, drm):
    v = xbmc.getInfoLabel("System.BuildVersion")
    major = int(re.search(r'(\d+)', v).group(1))
    
    LICENSE_URL = requests.get("http://10.21.4.90:5000/api/license_url/mtv/724573224212").content.decode("utf-8")

    if xbmc.Player().isPlaying():
        xbmc.Player().stop()

    play_item = xbmcgui.ListItem(path=stream)
    play_item.setContentLookup(False)
    play_item.setProperty("IsPlayable", "true")
    play_item.setInfo("Video", {"title": name, "plot": name})
    play_item.setArt({"fanart": addon_fanart, "thumb": logo, "icon": logo})
    play_item.setProperty("inputstream", "inputstream.adaptive")

    if ".mpd" in stream:
        play_item.setMimeType("application/dash+xml")
        play_item.setProperty("inputstream.adaptive.manifest_type", "mpd")

        #if drm != "false":
        if major >= 21:
            play_item.setProperty("inputstream.adaptive.drm_legacy", f"com.widevine.alpha|{LICENSE_URL}")
        else:
            play_item.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
            play_item.setProperty("inputstream.adaptive.license_key", f"{LICENSE_URL}||R{{SSM}}|")

    if ".m3u8" in stream:
        play_item.setMimeType("application/vnd.apple.mpegurl")

    xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
    xbmc.Player().play(item=stream, listitem=play_item)


if mode is None:
    menu()

elif mode[0] == "folder":
    provider = args["provider"][0]
    code = args["code"][0]
    submenu(provider, code)

elif mode[0] == "playlist":
    provider = args["provider"][0]
    code = args["code"][0]
    listtype = args["list"][0]
    manifest = manifest(provider)
    playlist(provider, code, listtype, manifest)

elif mode[0] == "play":
    stream = args["stream"][0]
    name = args["name"][0]
    logo = args["logo"][0]
    drm = args["drm"][0]
    play(stream, name, logo, drm)

elif mode[0] == "info":
    text = "Telerising API by Jan-Luca Neumann.[CR][CR]Download: https://github.com/DEvmIb/telerising-builds/releases[CR][CR]Support: https://www.kodinerds.net/thread/72127-telerising-api-zattoo-waipu-tv-blue-tv-sky-ch-für-tvheadend-und-vlc-web-app/[CR][CR]Donate: https://paypal.me/sunsettrack4"
    dialog = xbmcgui.Dialog()
    dialog.textviewer("Telerising", text)

elif mode[0] == "settings":
    addon.openSettings()
    xbmc.executebuiltin("Container.Refresh")
