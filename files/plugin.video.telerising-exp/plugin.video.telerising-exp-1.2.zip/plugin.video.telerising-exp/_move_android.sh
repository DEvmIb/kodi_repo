#scp -P 2222 -r ../plugin.video.telerising-exp root@10.21.1.93:/storage/emulated/0/kodi_21/.kodi/addons/
#scp -P 2222 -r ../plugin.video.telerising-exp root@10.21.1.9:/storage/emulated/0/kodi_21/.kodi/addons/
scp -P 2222 -r ../plugin.video.telerising-exp root@10.21.1.17:/storage/emulated/0/kodi_20/.kodi/addons/