import sys
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
from datetime import datetime, timezone

URL = "https://olympia.b3t4f4c3.de/olympia.json"
#URL = "http://127.0.0.1:5000/olympia.json"
HANDLE = int(sys.argv[1])

def get_data():
    try:
        # wir habe den scraper mit thread locking. timeout sollte hoch sein falls es mal laenger dauert.
        r = requests.get(URL, timeout=30)
        return r.json()
    except:
        return []

def list_events():
    
    refresh_url = sys.argv[0]
    li_refresh = xbmcgui.ListItem(label="[COLOR yellow]*** LISTE AKTUALISIEREN ***[/COLOR]")
    
    addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
    li_refresh.setArt({'icon': addon_icon, 'thumb': addon_icon})
    
    li_refresh.setInfo('video', {'plot': 'daten neu laden. der server cahced die daten 30 minuten. update alle 2 minuten lohnt also nicht :)'})
    
    xbmcplugin.addDirectoryItem(HANDLE, refresh_url, li_refresh, isFolder=True)

    events = get_data()
    for ev in events:
        try:
            start = ev['start'].replace('Z', '+00:00')
            utc = datetime.fromisoformat(start)
            local = utc.astimezone()
            h =local.strftime("%H:%M")
            d = local.strftime("%d.%m.")
        except:
            h = "??:??"
            d = ""

        label = f"[COLOR orange]{h}[/COLOR] {d} - [COLOR yellow]{ev['src']}[/COLOR] - {ev['title']}"
        
        li = xbmcgui.ListItem(label=label)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        #li.setMimeType('application/vnd.apple.mpegurl')
        li.setMimeType('application/x-mpegURL')
        li.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')
        li.setArt({'thumb': ev['image'], 'icon': ev['image'], 'fanart': ev['image']})
        li.setInfo('video', {'title': ev['title'], 'plot': ev['desc']})
        li.setProperty('IsPlayable', 'true')
        
        url = ev['stream']
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False, updateListing=True)

if __name__ == '__main__':
    list_events()