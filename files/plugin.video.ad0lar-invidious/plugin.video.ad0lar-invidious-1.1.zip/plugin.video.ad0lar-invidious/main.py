# -------------------------------------------------------------------------
# ad0lar's invidious client
# licensed under gpl-2.0-only
#
# hey! if you find this code useful and want to use it in your own
# project, i'd love to hear about it. it's not a legal requirement,
# but a message would make my day!
#
# https://github.com/DEvmIb
# -------------------------------------------------------------------------

# TODO unicode
# TODO merge list_videos

import sys
import urllib.parse
import urllib.request
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import html
import os
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])
base_url = sys.argv[0]

default_icon = os.path.join(addon.getAddonInfo("path"), "icon.png")
default_fanart = os.path.join(addon.getAddonInfo("path"), "fanart.png")

CACHE_DIR_VIDEOS = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("profile")), "video_cache")
SEARCH_HISTORY_FILE = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("profile")), "search_history.json")
CACHE_DIR_CHANNELS = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("profile")), "channels_cache")


def get_search_history():
    if xbmcvfs.exists(SEARCH_HISTORY_FILE):
        try:
            with xbmcvfs.File(SEARCH_HISTORY_FILE, "r") as f:
                return json.loads(f.read())
        except:
            return []
    return []


def save_search_query(query):
    history_max = int(addon.getSetting("max_results_history"))
    history = get_search_history()
    if query in history:
        history.remove(query)
    history.insert(0, query)
    history = history[:history_max]
    with xbmcvfs.File(SEARCH_HISTORY_FILE, "w") as f:
        f.write(json.dumps(history))


def get_video_cache_file(video_id):
    if not xbmcvfs.exists(CACHE_DIR_VIDEOS):
        xbmcvfs.mkdir(CACHE_DIR_VIDEOS)
    return os.path.join(CACHE_DIR_VIDEOS, f"video_{video_id}.json")


def save_video_to_cache(video_id, meta):
    cache_time = int(addon.getSetting("cache_time"))
    file_path = get_video_cache_file(video_id)
    with xbmcvfs.File(file_path, "w") as f:
        meta["cache_time"] = time.time() + cache_time
        f.write(json.dumps(meta))


def get_video_from_cache(video_id):
    file_path = get_video_cache_file(video_id)
    if xbmcvfs.exists(file_path):
        try:
            with xbmcvfs.File(file_path, "r") as f:
                data = json.loads(f.read())
                if data["cache_time"] > time.time():
                    return None
                else:
                    return data
        except:
            return None
    return None


def list_history(data, current_page):
    if not data:
        xbmcplugin.endOfDirectory(handle, False)
        return

    xbmcplugin.setContent(handle, "videos")

    for v_id in data:
        meta = get_video_from_cache(v_id)

        if not meta:
            v_data = call_api(f"videos/{v_id}")
            if v_data:
                meta = {
                    "title": prepare_text(v_data.get("title", "Unknown")),
                    "author": prepare_text(v_data.get("author", "Unknown")),
                    "thumb": v_data.get("videoThumbnails", [{}])[0].get("url", ""),
                    "duration": v_data.get("lengthSeconds", 0),
                    "desc": v_data.get("description", ""),
                    "pubText": v_data.get("publishedText", ""),
                    "published": v_data.get("published", 0),
                }
                save_video_to_cache(v_id, meta)
            else:
                continue

        li = xbmcgui.ListItem(label=meta["title"])
        info = li.getVideoInfoTag()
        info.setTitle(meta["title"])

        v_date = datetime.fromtimestamp(meta["published"])
        f_date = v_date.strftime("%Y-%m-%d, %H:%M")
        info.setPremiered(v_date.strftime("%Y-%m-%d"))
        info.setYear(v_date.year)

        info.setPlot(f"{get_lang(33016)}: {meta['author']}\n{get_lang(33017)}: {meta['title']}\n{get_lang(33018)}: {f_date}\n{get_lang(33024)}: {meta['desc']}")
        info.setDuration(meta["duration"])

        li.setArt({"thumb": meta["thumb"], "icon": meta["thumb"]})

        url = base_url + "?" + urllib.parse.urlencode({"action": "play", "video_id": v_id})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    if len(data) > 0:
        next_page = current_page + 1
        u = base_url + "?" + urllib.parse.urlencode({"action": "history", "page": next_page})
        nxt = xbmcgui.ListItem(label=f"[COLOR yellow]>> {get_lang(33003)} ({next_page}) <<[/COLOR]")
        nxt.setArt({"icon": default_icon, "thumb": default_icon})
        xbmcplugin.addDirectoryItem(handle, u, nxt, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def prepare_text(text):
    if not text:
        return ""
    try:
        last_text = ""
        while text != last_text:
            last_text = text
            text = html.unescape(text)
        if isinstance(text, bytes):
            text = text.decode("utf-8", "ignore")
        return text.strip()
    except Exception as e:
        return str(text)


def call_api(endpoint, params=None, method="GET"):
    server = addon.getSetting("server_url").strip().rstrip("/")
    raw_token = addon.getSetting("api_key").strip()
    selected_lang = addon.getSetting("language_code")
    if not server:
        addon.openSettings()
        return None
    if params is None:
        params = {}

    if method == "GET":
        params["hl"] = selected_lang
        params["lang"] = selected_lang
        params["tlang"] = selected_lang
        try:
            max_res = int(addon.getSetting("max_results"))
        except:
            max_res = 50
        if "max_results" not in params and "auth/subscriptions" not in endpoint:
            params["max_results"] = max_res
    url = f"{server}/api/v1/{endpoint}"
    if params and method == "GET":
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, method=method)
        if raw_token:
            req.add_header("Authorization", f"Bearer {raw_token}")
        with urllib.request.urlopen(req, timeout=10) as response:
            raw_data = response.read().decode("utf-8", "ignore")
            return json.loads(raw_data)
    except Exception as e:
        xbmc.log(f"[invidious] api error: {str(e)}", xbmc.LOGERROR)
        return None


def get_channel_cache(c_id):
    if not os.path.exists(CACHE_DIR_CHANNELS):
        os.makedirs(CACHE_DIR_CHANNELS)
    cache_file = os.path.join(CACHE_DIR_CHANNELS, f"{c_id}.json")
    if os.path.exists(cache_file):
        with open(cache_file, "r") as f:
            data = json.load(f)
            if data["cache_time"] < time.time():
                return None
            else:
                return data
    return None


def set_channel_cache(c_id, data):
    cache_time = int(addon.getSetting("cache_time"))
    cache_file = os.path.join(CACHE_DIR_CHANNELS, f"{c_id}.json")
    with open(cache_file, "w") as f:
        data["cache_time"] = time.time() + cache_time
        json.dump(data, f)


def list_channels(data):
    if not data:
        xbmcplugin.endOfDirectory(handle, False)
        return
    data.sort(key=lambda x: prepare_text(x.get("author", "")).lower())
    for channel in data:
        name = prepare_text(channel.get("author", get_lang(33013)))
        c_id = channel.get("authorId")
        if not c_id:
            continue
        list_item = xbmcgui.ListItem(label=name)
        info = list_item.getVideoInfoTag()
        info.setTitle(name)

        list_item.setArt({"fanart": default_fanart})

        cache_data = get_channel_cache(c_id)
        if cache_data:
            img_url = cache_data.get("thumb")
            # info.setPlot(cache_data.get("plot", ""))
            sub_count = cache_data.get("sub_count")
            description = cache_data.get("description")
            plot_text = f"{get_lang(33026)}: {sub_count:,}\n\n{description}"
            info.setPlot(plot_text)
            if img_url:
                list_item.setArt({"thumb": img_url, "icon": img_url, "poster": img_url})
        else:
            list_item.setArt({"icon": default_icon, "thumb": default_icon})
            info.setPlot(get_lang(33014))

        url = base_url + "?" + urllib.parse.urlencode({"action": "channel_videos", "channel_id": c_id, "page": 1, "update_meta": "true"})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)


def list_videos_page(data, current_action, current_page, query_params=None):
    if data is None:
        xbmcplugin.endOfDirectory(handle, False)
        return
    raw_items = []
    if isinstance(data, list):
        raw_items = data
    elif isinstance(data, dict):
        raw_items = raw_items + data.get("notifications", [])
        raw_items = raw_items + data.get("videos", [])
    video_list = raw_items
    if current_action in ["feed", "channel_videos", "search"]:
        video_list.sort(key=lambda x: x.get("published", 0), reverse=True)
    xbmcplugin.setContent(handle, "videos")
    for video in video_list:
        v_id = video.get("videoId")
        if not v_id:
            continue
        title = prepare_text(video.get("title", "unknown"))
        author = prepare_text(video.get("author", "unknown"))
        views = video.get("viewCount", 0)
        raw_pub = video.get("published")
        list_item = xbmcgui.ListItem(label=title)
        info = list_item.getVideoInfoTag()
        info.setTitle(title)
        try:
            v_date = datetime.fromtimestamp(raw_pub)
            f_date = v_date.strftime("%Y-%m-%d, %H:%M")
            info.setPremiered(v_date.strftime("%Y-%m-%d"))
            info.setYear(v_date.year)
        except:
            f_date = get_lang(33015)
        views_pretty = "{:,}".format(views) if isinstance(views, int) else str(views)
        plot = f"{get_lang(33017)}: {title}\n{get_lang(33016)}: {author}\n{get_lang(33019)}: {views_pretty}\n{get_lang(33018)}: {f_date}"
        info.setPlot(plot)
        if author:
            info.setStudios([author])
        if video.get("lengthSeconds"):
            info.setDuration(int(video.get("lengthSeconds")))
        thumbs = video.get("videoThumbnails", [])
        t_url = ""
        if thumbs:
            for q in ["maxres", "maxresdefault", "sddefault", "high"]:
                for t in thumbs:
                    if t.get("quality") == q:
                        t_url = t.get("url")
                        break
                if t_url:
                    break
            if not t_url:
                t_url = thumbs[0].get("url")

        if t_url:
            list_item.setArt({"thumb": t_url, "icon": t_url, "fanart": t_url})
        else:
            list_item.setArt({"thumb": default_icon, "icon": default_icon, "fanart": default_fanart})

        url = base_url + "?" + urllib.parse.urlencode({"action": "play", "video_id": v_id})
        list_item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)
    if current_action not in ["trending", "popular"] and len(video_list) > 0:
        next_page = current_page + 1
        p_params = {"action": current_action, "page": next_page}
        if query_params:
            p_params.update(query_params)
        u = base_url + "?" + urllib.parse.urlencode(p_params)
        nxt = xbmcgui.ListItem(label=f"[COLOR yellow]>> {get_lang(33003)} (%d)[/COLOR]" % next_page)
        nxt.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
        xbmcplugin.addDirectoryItem(handle, u, nxt, isFolder=True)
    xbmcplugin.endOfDirectory(handle)


def list_videos(data, current_action, current_page, query_params=None):
    if data is None:
        xbmcplugin.endOfDirectory(handle, False)
        return

    raw_items = []
    continuation = None
    if isinstance(data, list):
        raw_items = data
    elif isinstance(data, dict):
        raw_items = data.get("videos", []) or data.get("notifications", []) or []
        continuation = data.get("continuation")
    if current_action in ["feed", "channel_videos", "search"] and not continuation:
        raw_items.sort(key=lambda x: x.get("published", 0), reverse=True)

    xbmcplugin.setContent(handle, "videos")

    for video in raw_items:
        v_id = video.get("videoId")
        if not v_id:
            continue

        title = prepare_text(video.get("title", "unknown"))
        author = prepare_text(video.get("author", "unknown"))
        desc = prepare_text(video.get("description", ""))

        list_item = xbmcgui.ListItem(label=title)
        info = list_item.getVideoInfoTag()
        info.setTitle(title)
        f_date = get_lang(33015)
        raw_pub = video.get("published")
        try:
            if raw_pub and int(raw_pub) > 0:
                v_date = datetime.fromtimestamp(int(raw_pub))
                # TODO invidious bug?
                if v_date.hour == 0 and v_date.minute == 0:
                    f_date = v_date.strftime("%d.%m.%Y")
                else:
                    f_date = v_date.strftime("%d.%m.%Y, %H:%M")

                info.setPremiered(v_date.strftime("%Y-%m-%d"))
                info.setYear(v_date.year)
        except:
            pass
        views_pretty = "{:,}".format(video.get("viewCount", 0)) if isinstance(video.get("viewCount"), int) else str(video.get("viewCount", 0))
        v_index = video.get("index", 0)
        current_v_idx = v_index if v_index > 0 else (raw_items.index(video) + 1 + ((current_page - 1) * 50))

        plot = f"{get_lang(33016)}: {author}\n{get_lang(33017)}: {title}\n{get_lang(33018)}: {f_date}\n{get_lang(33019)}: {views_pretty}\n{desc}"
        info.setPlot(plot)
        info.setDuration(video.get("lengthSeconds", 0))
        thumbs = video.get("videoThumbnails", [])
        if thumbs:
            img = thumbs[0].get("url", "")
            if img:
                list_item.setArt({"thumb": img, "icon": img, "fanart": img})
            else:
                list_item.setArt({"thumb": default_icon, "icon": default_icon, "fanart": default_fanart})
        else:
            list_item.setArt({"thumb": default_icon, "icon": default_icon, "fanart": default_fanart})

        url = base_url + "?" + urllib.parse.urlencode({"action": "play", "video_id": v_id})
        list_item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)
    if current_action not in ["trending", "popular"] and len(raw_items) > 0:
        if continuation or len(raw_items) >= 50:
            next_page = current_page + 1
            p_params = {"action": current_action, "page": next_page}

            if continuation:
                p_params["continuation"] = continuation

            if query_params:
                p_params.update(query_params)

            u = base_url + "?" + urllib.parse.urlencode(p_params)

            label = f"[COLOR yellow]>> {get_lang(33002)}[/COLOR]" if continuation else f"[COLOR yellow]>> {get_lang(33003)} ({next_page})[/COLOR]"
            nxt = xbmcgui.ListItem(label=label)
            nxt.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
            xbmcplugin.addDirectoryItem(handle, u, nxt, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def channel_pl_list_videos(data, current_action, current_page, query_params=None):
    if data is None:
        xbmcplugin.endOfDirectory(handle, False)
        return

    raw_items = []
    total_videos_api = 0

    if isinstance(data, list):
        raw_items = data
        total_videos_api = len(data)
    elif isinstance(data, dict):
        raw_items = data.get("videos", []) or data.get("notifications", []) or []
        total_videos_api = data.get("videoCount", len(raw_items))

    if current_action in ["feed", "channel_videos", "search"]:
        raw_items.sort(key=lambda x: x.get("published", 0), reverse=True)

    xbmcplugin.setContent(handle, "videos")

    for video in raw_items:
        v_id = video.get("videoId")
        if not v_id:
            continue

        title = prepare_text(video.get("title", "unknown"))
        author = prepare_text(video.get("author", "unknown"))

        list_item = xbmcgui.ListItem(label=title)
        info = list_item.getVideoInfoTag()
        info.setTitle(title)

        v_index = video.get("index", 0)
        views_pretty = "{:,}".format(video.get("viewCount", 0))

        current_v_idx = v_index if v_index > 0 else (raw_items.index(video) + 1)
        plot = f"{get_lang(33017)}: {title}\n{get_lang(33016)}: {author}\n{get_lang(33019)}: {views_pretty}"
        info.setPlot(plot)

        thumbs = video.get("videoThumbnails", [])
        if thumbs:
            img = thumbs[0].get("url", "")
            list_item.setArt({"thumb": img, "icon": img, "fanart": img})

        url = base_url + "?" + urllib.parse.urlencode({"action": "play", "video_id": v_id})
        list_item.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)

    if total_videos_api > len(raw_items) and len(raw_items) > 0:
        next_page = current_page + 1
        p_params = {"action": current_action, "page": next_page}
        if query_params:
            p_params.update(query_params)

        u = base_url + "?" + urllib.parse.urlencode(p_params)
        nxt = xbmcgui.ListItem(label=f"[COLOR yellow]>> {get_lang(33002)} (currently {len(raw_items)}/{total_videos_api})[/COLOR]")
        nxt.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
        xbmcplugin.addDirectoryItem(handle, u, nxt, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def list_playlists(data):
    if not data:
        xbmcplugin.endOfDirectory(handle, False)
        return
    for pl in data:
        title = prepare_text(pl.get("title", get_lang(33020)))
        pl_id = pl.get("playlistId")
        if not pl_id:
            continue
        list_item = xbmcgui.ListItem(label=title)
        info = list_item.getVideoInfoTag()
        info.setTitle(title)
        # TODO no thumb in json
        thumb = pl.get("thumbnail")
        if thumb:
            list_item.setArt({"thumb": thumb, "icon": thumb, "poster": thumb, "fanart": thumb})
        else:
            list_item.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
        video_count = pl.get("videoCount", 0)
        info.setPlot(f"{get_lang(33025)}: {title}\n{get_lang(33022)}: {video_count}")
        url = base_url + "?" + urllib.parse.urlencode({"action": "playlist_videos", "playlist_id": pl_id})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(handle)


def play_video(video_id):
    server = addon.getSetting("server_url").strip().rstrip("/")
    ask_quality = addon.getSetting("inputstream_quality") == "true"
    manifest_url = f"{server}/companion/api/manifest/dash/id/{video_id}"
    play_item = xbmcgui.ListItem(path=manifest_url)
    play_item.setProperty("inputstream", "inputstream.adaptive")
    play_item.setProperty("inputstream.adaptive.manifest_type", "mpd")
    if ask_quality:
        play_item.setProperty("inputstream.adaptive.stream_selection_type", "ask-quality")
    else:
        play_item.setProperty("inputstream.adaptive.stream_selection_type", "auto")
    play_item.setMimeType("application/dash+xml")
    play_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, play_item)
    call_api(f"auth/history/{video_id}", method="POST")


class SetupHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/images/"):
            image_name = self.path.split("/")[-1]
            image_path = os.path.join(addon.getAddonInfo("path"), "resources", image_name)

            if os.path.exists(image_path):
                self.send_response(200)
                if image_name.endswith(".png"):
                    self.send_header("Content-type", "image/png")
                else:
                    self.send_header("Content-type", "image/jpeg")
                self.end_headers()
                with open(image_path, "rb") as f:
                    self.wfile.write(f.read())
                return
            else:
                self.send_error(404, "image not found")
                return
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        safe_token = addon.getSetting("api_key").replace('"', "&quot;")
        safe_server = addon.getSetting("server_url").replace('"', "&quot;")
        html_code = f"""
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {{ font-family: sans-serif; background: #121212; color: #efefef; padding: 20px; line-height: 1.6; text-transform: lowercase; }}
            .container {{ max-width: 600px; margin: auto; background: #1e1e1e; padding: 25px; border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.7); }}
            h1, h2 {{ color: #0084ff; text-align: center; }}
            .step {{ background: #2a2a2a; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #0084ff; }}
            .screenshot {{ width: 100%; border-radius: 6px; margin-top: 10px; cursor: pointer; border: 1px solid #444; transition: 0.3s; }}
            .screenshot:hover {{ opacity: 0.8; transform: scale(1.02); }}
            input {{ width: 100%; padding: 12px; margin: 10px 0; border-radius: 4px; border: 1px solid #333; background: #2a2a2a; color: white; box-sizing: border-box; }}
            input[type="submit"] {{ background: #0084ff; border: none; font-weight: bold; cursor: pointer; margin-top: 20px; font-size: 1.1em; text-transform: lowercase; }}
            .hint {{ font-size: 0.9em; color: #aaa; text-align: center; }}
        </style></head><body>
        <div class="container">
            <h1>invidious setup</h1>
            
            <div class="step">
                <strong>step 1: invidious url</strong><br>
                navigate to the authorization page by replacing [hostname] in this link with your instance's address: http://[hostname]/authorize_token?scopes=:*
            </div>

            <div class="step">
                <strong>step 2: get token</strong><br>
                if you are logged out, please log into your instance until you see this question                
                    <img src="/images/step2.png" class="screenshot" title="token question">
            </div>

            <div class="step">
                <strong>step 3: copy token</strong><br>
                after clicking 'yes', your token will be displayed. copy everything including the {{ and }} brackets and paste it into the api key field below.             
                    <img src="/images/step3.png" class="screenshot" title="token screenshot">
            </div>

            <form method="POST">
                <h2>enter data</h2>
                server url:<br><input type="text" name="server" value="{safe_server}" placeholder="https://invidious.io">
                api key (token):<br><input type="text" name="token" value="{safe_token}" placeholder="your secret token">
                <input type="submit" value="save & test">
            </form>
            <p class="hint">click images to view them in full size.</p>
        </div></body></html>
        """
        self.wfile.write(html_code.encode("utf-8"))

    def do_POST(self):
        selected_lang = addon.getSetting("language_code")
        content_length = int(self.headers["Content-Length"])
        post_data = self.rfile.read(content_length).decode("utf-8")
        params = urllib.parse.parse_qs(post_data)
        server = params.get("server", [""])[0].strip().rstrip("/")
        token = params.get("token", [""])[0].strip()
        test_success = False
        try:
            test_url = f"{server}/api/v1/auth/subscriptions?hl={selected_lang}&lang={selected_lang}&tlang={selected_lang}"
            req = urllib.request.Request(test_url)
            req.add_header("Authorization", f"Bearer {token}")
            with urllib.request.urlopen(req, timeout=5) as r:
                if r.getcode() == 200:
                    test_success = True
        except:
            pass

        if test_success:
            addon.setSetting("server_url", server)
            addon.setSetting("api_key", token)

        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()

        if test_success:
            msg = "<h1>connection successful!</h1><p>everything is okay, you can close the browser now and return to kodi.</p>"
            color = "#00ff00"
        else:
            msg = "<h1>test failed!</h1><p>please check your server url and api-key (token) again.</p>"
            color = "#ff0000"

        response_html = f"""
        <html><body style='background:#121212;color:white;font-family:sans-serif;text-align:center;padding-top:50px;text-transform:lowercase;'>
            <div style='color:{color};'>{msg}</div>
            <p><a href='/' style='color:#0084ff;text-decoration:none;'>&lt;&lt; back to form</a></p>
        </body></html>
        """
        self.wfile.write(response_html.encode("utf-8"))


def start_setup_server(stop_event):
    global global_setup_port
    try:
        server = HTTPServer(("0.0.0.0", 0), SetupHandler)
        global_setup_port = server.server_port
        server.timeout = 0.5
        while not stop_event.is_set():
            server.handle_request()
        server.server_close()
    except:
        pass


def channel_list_playlists(data, c_id):
    if not data:
        xbmcplugin.endOfDirectory(handle, False)
        return

    playlists = data.get("playlists", []) if isinstance(data, dict) else data
    continuation = data.get("continuation") if isinstance(data, dict) else None

    for pl in playlists:
        title = prepare_text(pl.get("title", get_lang(33020)))
        author = prepare_text(pl.get("author", get_lang(33021)))
        p_id = pl.get("playlistId")
        if not p_id:
            continue

        li = xbmcgui.ListItem(label=title)
        v_count = pl.get("videoCount", 0)
        li.setInfo("video", {"plot": f"{get_lang(33016)}: {author}\n{get_lang(33022)}: {v_count}", "title": title})

        if pl.get("playlistThumbnail"):
            li.setArt({"thumb": pl.get("playlistThumbnail"), "icon": pl.get("playlistThumbnail")})

        url = base_url + "?" + urllib.parse.urlencode({"action": "channel_playlist_videos", "playlist_id": p_id, "page": 1})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    if continuation:
        u = base_url + "?" + urllib.parse.urlencode({"action": "channel_playlists", "channel_id": c_id, "continuation": continuation})
        nxt = xbmcgui.ListItem(label=f"[COLOR yellow]>> {get_lang(33023)}[/COLOR]")
        nxt.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
        xbmcplugin.addDirectoryItem(handle, u, nxt, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def get_lang(id):
    return addon.getLocalizedString(id)


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    page = int(params.get("page", 1))
    if not action:
        menu = [
            (f" [COLOR orange]>> {get_lang(33010)} <<[/COLOR]", "setup"),
            (get_lang(33001), "start_search"),
            (get_lang(33009), "feed"),
            (get_lang(33008), "subscriptions"),
            (get_lang(33004), "trending"),
            (get_lang(33005), "popular"),
            (get_lang(33006), "playlists"),
            (get_lang(33007), "history"),
        ]
        for label, act in menu:
            url = base_url + "?" + urllib.parse.urlencode({"action": act, "page": 1})
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
        xbmcplugin.endOfDirectory(handle)

    elif action == "setup":
        stop_event = threading.Event()
        global global_setup_port
        global_setup_port = 0
        thread = threading.Thread(target=start_setup_server, args=(stop_event,))
        thread.daemon = True
        thread.start()
        xbmc.sleep(500)
        import socket

        ip = "kodi-ip"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            s.close()
        except:
            try:
                ip = socket.gethostbyname(socket.gethostname())
            except:
                pass
        xbmcgui.Dialog().ok("web-setup active", f"{get_lang(33011)}: [{global_setup_port}]: http://{ip}:{global_setup_port}")
        stop_event.set()

    elif action == "subscriptions":
        list_channels(call_api("auth/subscriptions"))
    elif action == "channel_videos_old":
        selected_lang = addon.getSetting("language_code")
        c_id = params.get("channel_id")
        if params.get("update_meta") == "true" and not get_channel_cache(c_id):
            c_details = call_api(f"channels/{c_id}", {"hl": selected_lang, "lang": selected_lang, "tlang": selected_lang})
            if c_details:
                img_url = c_details.get("authorThumbnails", [{}])[-1].get("url", "")
                sub_count = c_details.get("subCount", 0)
                description = c_details.get("description", "")
                # plot_text = f"{get_lang(33026)}: {sub_count:,}\n\n{c_details.get('description', '')}"
                set_channel_cache(c_id, {"thumb": img_url, "sub_count": sub_count, "description": description})
        if page == 1:
            pl_item = xbmcgui.ListItem(label=f"[COLOR orange]>> {get_lang(33012)} <<[/COLOR]")
            pl_item.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
            url_pls = base_url + "?" + urllib.parse.urlencode({"action": "channel_playlists", "channel_id": c_id})
            xbmcplugin.addDirectoryItem(handle, url_pls, pl_item, isFolder=True)
        list_videos(call_api(f"channels/{c_id}/videos", {"page": page}), action, page, query_params={"channel_id": c_id})

    elif action == "channel_videos":
        c_id = params.get("channel_id")
        cont_token = params.get("continuation")
        lang = addon.getSetting("language_code") or "en"

        if params.get("update_meta") == "true" and not get_channel_cache(c_id):
            c_details = call_api(f"channels/{c_id}", {"hl": lang})
            if c_details:
                img_url = c_details.get("authorThumbnails", [{}])[-1].get("url", "")
                sub_count = c_details.get("subCount", 0)
                description = c_details.get("description", "")
                # plot_text = f"{get_lang(33026)}: {sub_count:,}\n\n{c_details.get('description', '')}"
                set_channel_cache(c_id, {"thumb": img_url, "sub_count": sub_count, "description": description})

        api_params = {}
        if cont_token:
            api_params["continuation"] = cont_token
        else:
            api_params["page"] = page

        if not cont_token:
            pl_item = xbmcgui.ListItem(label=f"[COLOR orange]>> {get_lang(33012)} <<[/COLOR]")
            pl_item.setArt({"icon": default_icon, "thumb": default_icon, "fanart": default_fanart})
            url_pls = base_url + "?" + urllib.parse.urlencode({"action": "channel_playlists", "channel_id": c_id})
            xbmcplugin.addDirectoryItem(handle, url_pls, pl_item, isFolder=True)

        list_videos(call_api(f"channels/{c_id}/videos", api_params), action, page, query_params={"channel_id": c_id})
    elif action == "feed":
        list_videos_page(call_api("auth/feed", {"page": page}), action, page)
    elif action == "trending":
        list_videos(call_api("trending"), action, page)
    elif action == "popular":
        list_videos(call_api("popular"), action, page)
    elif action == "start_search_old":
        q = params.get("q")
        if not q:
            q = xbmcgui.Dialog().input("search", type=xbmcgui.INPUT_ALPHANUM)
        if q:
            list_videos_page(call_api("search", {"q": q, "page": 1}), "search", 1, query_params={"q": q})
        else:
            xbmcplugin.endOfDirectory(handle, False)
    elif action == "start_search":
        q = params.get("q")
        if q:
            save_search_query(q)
            data = call_api("search", {"q": q, "page": 1})
            list_videos_page(data, "start_search", 1, query_params={"q": q})
        else:
            li = xbmcgui.ListItem(label=f"[COLOR orange]>> {get_lang(33000)} <<[/COLOR]")
            li.setArt({"icon": "DefaultAddonsSearch.png", "thumb": default_icon, "fanart": default_fanart})

            url = base_url + "?" + urllib.parse.urlencode({"action": "new_search_dialog"})
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

            history = get_search_history()
            for entry in history:
                li = xbmcgui.ListItem(label=entry)
                li.setArt({"icon": "DefaultAddonsSearch.png", "thumb": default_icon, "fanart": default_fanart})
                url = base_url + "?" + urllib.parse.urlencode({"action": "start_search", "q": entry})
                xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

            xbmcplugin.endOfDirectory(handle)

    elif action == "new_search_dialog":
        q = xbmcgui.Dialog().input("Search", type=xbmcgui.INPUT_ALPHANUM)
        if q:
            save_search_query(q)
            url = base_url + "?" + urllib.parse.urlencode({"action": "start_search", "q": q})
            xbmc.executebuiltin(f"Container.Update({url})")

    elif action == "search":
        q = params.get("q")
        list_videos_page(call_api("search", {"q": q, "page": page}), action, page, query_params={"q": q})

    elif action == "play":
        play_video(params.get("video_id"))
    elif action == "playlists":
        list_playlists(call_api("auth/playlists"))
    elif action == "playlist_videos":
        p_id = params.get("playlist_id")
        list_videos(call_api(f"auth/playlists/{p_id}"), action, page, query_params={"playlist_id": p_id})
    elif action == "channel_playlists":
        c_id = params.get("channel_id")
        cont_token = params.get("continuation")
        api_params = {}
        if cont_token:
            api_params["continuation"] = cont_token
        else:
            api_params["page"] = page
        channel_list_playlists(call_api(f"channels/{c_id}/playlists", api_params), c_id)

    elif action == "channel_playlist_videos":
        p_id = params.get("playlist_id")
        channel_pl_list_videos(call_api(f"playlists/{p_id}"), action, page, query_params={"playlist_id": p_id})

    elif action == "history":
        history_max = int(addon.getSetting("max_results_history"))
        history_data = call_api("auth/history", {"page": page, "max_results": history_max})
        list_history(history_data, page)


if __name__ == "__main__":
    run()
